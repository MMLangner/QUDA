@ECHO off

python3 -V | find /v "Python" >NUL 3>NUL && (goto :PYTHON_DOES_NOT_EXIST)
python3 -V | find "Python" >NUL 3>NUL && (goto :PYTHON_DOES_EXIST)
PAUSE

:PYTHON_DOES_NOT_EXIST
ECHO Python is not installed on your system.
ECHO Now opening the download URL.
START "" "https://www.python.org/downloads/macos/"
PAUSE

:PYTHON_DOES_EXIST
ECHO Your computer runs Python, continueing to setup QUDA...
ECHO installing dependencies of QUDA...
#brew install python3
pip3 install django
pip3 install django_downloadview
pip3 install numpy
ECHO requirements installed. Please use QUDA_start file to start app.
PAUSE