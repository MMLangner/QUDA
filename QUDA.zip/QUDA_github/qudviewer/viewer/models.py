from django.db import models
from django.template import Context, Template, loader
import uuid
import xml.etree.ElementTree as et
from django.views.static import serve
from io import StringIO




class PLAIN:
    def __init__(self, txt):
        self.text = txt

    def toHTML(self, request):
        template = loader.get_template("viewer/plain.html")

        context = {"plaintext":self.text}
        return template.render(context, request)




class Document:
    def __init__(self, config, XMLroot):
        self.root = XMLroot
        self.rootqud = self.parse(config, self.root)
        #self.rootqud[0].printData()
        self.identifyQUD()


    def getAllUnclassifiedSegments(self, rqud, arr):
        for subq in rqud.subQUDs:
            self.getAllUnclassifiedSegments(subq, arr)

        for segm in rqud.segList:
            if segm.classification == "":
                arr.append(segm.idn)


    

    def findByID(self, someObj, idnn, previous=None):

        if someObj.type == "QUD":

            print("IDN found: ",someObj.idn)
            print("IDN in search: ", idnn)
            if someObj.idn == idnn:
                return someObj, previous
            else:
                for subq in someObj.subQUDs:
                    subqBool, subqPrev = self.findByID(subq, idnn, someObj)
                    if subqBool:
                        return subqBool, subqPrev

                for segm in someObj.segList:
                    subSBool, subSPrev = self.findByID(segm, idnn, someObj)
                    if subSBool:
                        return subSBool, subSPrev
            
            return False, False

        else:
            if someObj.idn == idnn:
                return someObj, previous
            else:
                for segm in someObj.subsegments:
                    subSBool, subSPrev = self.findByID(segm, idnn, someObj)
                    if subSBool:
                        return subSBool, subSPrev
            
            return False, False



    def findQUD(self, someObj, idnn):
        
        if someObj.type == "QUD":

            if someObj.identifier == idnn:
                return someObj
            else:
                for subq in someObj.subQUDs:
                    subidn = self.findQUD(subq, idnn)
                    if subidn:
                        return subidn
        return False




    def parse(self, config, root):
        allquds = []
        for elem in root:
            if elem.tag == "QUD":
                this_q = QUD(elem.get("string"), elem)
                this_q.subQUDs = self.parse("testconfig", elem)
                allquds.append(this_q)
            else:
                continue
        return allquds

    def toHTML(self, request):
        htmlmarkup = self.rootqud[0].toHTML(request)
        return htmlmarkup
        

    def identifyQUD(self):
        i = 0
        ident = "Q." + str(i)
        if len(self.rootqud) == 0:
            return 0
        self.rootqud[0].identifier = ident
        i += 1
        print(ident)
        for subq in self.rootqud[0].subQUDs:
            self.recursiveIdentifying(subq, i,  None)
            i += 1

    
    def toXML(self):
        root = et.Element("ROOT")
        rootqud = et.SubElement(root, "QUD", string=self.rootqud[0].qudForm)

        for subseg in self.rootqud[0].segList:
            subsgm = subseg.toXML(rootqud)

        for subqud in self.rootqud[0].subQUDs:
            subq = subqud.toXML(rootqud)
        

        tree = et.ElementTree(root)
        return et.tostring(root, "utf-8").decode("utf-8")

    def recursiveIdentifying(self, qud, i, previous):

        j = 1
        print("recursive call")
        if previous == None:
            ident = "Q." + str(i)
            qud.identifier = ident
            print(ident)
            for q in qud.subQUDs:
                self.recursiveIdentifying(q, j, ident)
                j += 1
        else:
            ident = previous + "." + str(i)
            qud.identifier = ident
            print(ident)
            for q in qud.subQUDs:
                self.recursiveIdentifying(q, j, ident)
                j += 1


class QUD:
    def __init__(self,string, subtree):
        self.type = "QUD"
        self.identifier = ""
        self.subtree = subtree
        self.qudForm = string
        self.subQUDs = []
        self.segList = self.parseElems(subtree, [])
        self.idn = str(uuid.uuid4())


    def printData(self):
        print("QUD: ", self.qudForm)
        for seg in self.segList:
            seg.printSegment()

        
        for qud in self.subQUDs:
            qud.printData()
        
        


    def toXML(self, superqud):
        this_subq = et.SubElement(superqud, "QUD", string = self.qudForm)
        for seg in self.segList:
            seg.toXML(this_subq)
        
        for sq in self.subQUDs:
            sq.toXML(this_subq)

        




    def parse(self):
        listing = self.recurse(self.subtree, "SEGMENT", "QUD")
        listing = [SEGMENT(x) for x in listing]
        #print(listing)
        return listing

    

    def parseElems(self, root, parent):
        allSegments = []
        labels = ["AT","CT", "DT", "F", "CMT", "CON", "NAI", "RES"]
        for elem in root:
            if elem.tag in labels:
                i = 0
                indexlist = []
                sgmts = {}
                for subelem in elem:
                    sgmts[i] = subelem
                    if subelem.tag == "SEGMENT":
                        indexlist.append(i)
                    i += 1


                if len(indexlist) > 0:
                    for s in range(0, indexlist[0]):
                        this_seg = SEGMENT("")
                        this_seg.classification = sgmts[indexlist[s]].tag
                        this_seg.text = sgmts[indexlist[s]].text
                        this_seg.subsegments += self.deepparse(sgmts[s], [this_seg])
                        allSegments.append(this_seg)




                for ind in range(len(indexlist)):

                    this_seg = SEGMENT("")
                    this_seg.classification = elem.tag
                    this_seg.text = sgmts[indexlist[ind]].text
                    #print(sgmts[indexlist[ind]].text)
                    try:    
                        for s in range(indexlist[ind], indexlist[ind+1]):
                            this_seg.subsegments += self.deepparse(sgmts[s], [this_seg])
                        allSegments.append(this_seg)
                    except:
                        for s in range(indexlist[ind], len(elem.getchildren())):
                            this_seg.subsegments += self.deepparse(sgmts[s], [this_seg])
                        allSegments.append(this_seg)
                
            else:
                continue
            
            

        return allSegments


    def deepparse(self, elem, parent):
        labels = ["AT","CT", "DT", "F", "CMT", "CON", "NAI", "RES"]
        allSegments = []
        if elem.tag in labels:
            i = 0
            indexlist = []
            sgmts = {}
            for subelem in elem:
                sgmts[i] = subelem
                if subelem.tag == "SEGMENT":
                    indexlist.append(i)
                i += 1
            
            if len(indexlist) > 0:
                for s in range(0, indexlist[0]):
                    this_seg = SEGMENT("")
                    this_seg.classification = sgmts[indexlist[s]].tag
                    this_seg.text = sgmts[indexlist[s]].text
                    this_seg.subsegments += self.deepparse(sgmts[s], [this_seg])
                    allSegments.append(this_seg)

            for ind in range(len(indexlist)):

                this_seg = SEGMENT("")
                this_seg.classification = elem.tag
                this_seg.text = sgmts[indexlist[ind]].text
                try:    
                    for s in range(indexlist[ind], indexlist[ind+1]):
                        this_seg.subsegments += self.deepparse(sgmts[s], [this_seg])
                    
                except:
                    for s in range(indexlist[ind], len(elem.getchildren())):
                        this_seg.subsegments += self.deepparse(sgmts[s], [this_seg])
                
                allSegments.append(this_seg)

            
        else:
            pass
        return allSegments






    def recurse(self, root, get, block):
        allnodes = []
        
        #print(len(root))
        for elem in root:
            #print(elem.tag)
            if elem.tag == get:
                allnodes.append(elem.text)
            elif elem.tag == block:
                continue
            else:
                allnodes += self.recurse(elem, get, block)
        return allnodes

    def joinSegments(self):
        if len(self.segList) > 0:
            allsegments = ""
            for seg in self.segList:
                allsegments += seg.text
            this_seg = SEGMENT(allsegments)
            self.segList = [this_seg]
        else:
            pass


    def toHTML(self, request):
        template = loader.get_template("viewer/qud.html")
        segment_markup = ""
        for seg in self.segList:
            segment_markup += (seg.toHTML(request) + "\n")
        subqud_markup = ""
        for subqud in self.subQUDs:
            subqud_markup += (subqud.toHTML(request) + "\n")

        context = {"name":str(self.idn), "idn":str(self.idn), "idn_del":str(self.idn)+"_del","qud":self.qudForm, "ident":self.identifier,
        "deepembed":(segment_markup + "\n" + subqud_markup)}
        return template.render(context, request)


class SEGMENT:
    def __init__(self, string):
        self.type = "SEGMENT"
        self.text = string
        self.idn = str(uuid.uuid4())
        self.classification = ""
        self.subsegments = []
        self.identifier = ""

    def toXML(self, superElem):
        
        this_seg = et.SubElement(superElem, self.classification)

        if self.identifier == "":
            segm = et.SubElement(this_seg, "SEGMENT")
        else:
            segm = et.SubElement(this_seg, "SEGMENT", id=self.identifier)
        segm.text = self.text

        for subseg in self.subsegments:
            subseg.toXML(this_seg)


    def printSegment(self): #, depth):
        print("class: ", self.classification)
        print("string: ", self.text)
        #depth += 1

        for subseg in self.subsegments:
            subseg.printSegment()

    def toHTML(self, request):
        template = loader.get_template("viewer/segment.html")
        subtags = ""
        if len(self.subsegments) > 0:
            for subelem in self.subsegments:
                subtags += (subelem.toHTML(request) + "\n")
        #print(subtags)   
        context = {"segment":self.text, "name":str(self.idn), "idn":str(self.idn), "idn_del":str(self.idn)+"_del", "wraplabel":str(self.classification), "COL":str(self.classification), "wrapid":self.identifier, "deepembedseg":subtags}
        return template.render(context, request)
