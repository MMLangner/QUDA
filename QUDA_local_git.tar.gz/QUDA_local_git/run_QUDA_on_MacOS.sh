@ECHO off
ECHO %cd%
cd qudviewer/
python3 manage.py runserver
ECHO app started. Please open Firefox and direct to localhost (127.0.0.1:8000/apps/viewer/).
start "" "127.0.0.1:8000/apps/viewer/"
PAUSE