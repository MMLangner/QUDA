from django.shortcuts import render, redirect

# Create your views here.

from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from django.urls import reverse
from viewer.models import *
import os


from django_downloadview import VirtualDownloadView
from django_downloadview import VirtualFile
from django.core.files.storage import FileSystemStorage
from django.contrib.auth import authenticate, login, logout


import xml.etree.ElementTree as et


def loggingin(request):
    template = loader.get_template("viewer/login.html")
    context = {}
    return HttpResponse(template.render(context,request))


def checklogin(request):
    if request.method == 'POST' and "usrname" in request.POST.keys():
        usrname = request.POST["usrname"]
        pswd = request.POST["usrpasswd"]
        user = authenticate(request, username=usrname, password=pswd)
        if user is not None:
            login(request, user)
            return HttpResponseRedirect(reverse('viewer:index'))
        else:
            return HttpResponseRedirect(reverse('viewer:loggingin'))

            



def loggingout(request):
    if request.method == 'POST' and "logout" in request.POST.keys():
        if request.session.get("lbadge_int",0) == 0 and request.session.get("rbadge_int",0) == 0:
       
            logout(request)
            return HttpResponseRedirect(reverse('viewer:loggingin'))

        else:
            request.session["overlay"] = True
            request.session["message"] = "Please save your progress before logging out!"
            return HttpResponseRedirect(reverse('viewer:index'))

def index(request, scroll=0):
    
    if request.user.is_authenticated:
        print("user is already authenticated")

        try:
            
            docuLeft =  request.session["leftfile"]
            markup1 = docuLeft.toHTML(request)
            print("left file opened")
        except:
            markup1 = ""


        try:
            docuRight =  request.session["rightfile"]
            markup2 = docuRight.toHTML(request)
            print(markup2)
            print("right file opened")
        except:
            markup2 = ""
            request.session["toggleFileType"] = request.session.get("toggleFileType", "TXT")
            print("default file type set: ", request.session["toggleFileType"])


       
        try:
            scroll = request.session["scrollPos"]
        except:
            scroll = 0
        
        

      
        lb = request.session.get("lbadge_int",0)
        rb = request.session.get("rbadge_int",0)
   
        template = loader.get_template("viewer/surface.html")
        context = {"message":"", "overlay":0, "leftfile":markup1, "rightfile":markup2, "reload":scroll, "lb":lb, "rb":rb, "filetype":request.session["toggleFileType"]}   
        if "overlay" in request.session.keys():
            print("active overlay")
            message = request.session["message"]
            del request.session["message"]
            del request.session["overlay"]
            context["message"] = message
            context["overlay"] = "block"

        return HttpResponse(template.render(context, request))
    else:
        return HttpResponseRedirect(reverse('viewer:loggingin'))



def openFile(request):
    
    if request.method == 'POST' and "leftfile" in request.FILES.keys():
        myfile = request.FILES['leftfile']
        request.session["lfile_name"] = myfile.name
        fs = FileSystemStorage()
        myfile1 = fs.save(myfile.name, myfile)
        tree = et.parse(myfile1)
        root = tree.getroot()
        docu = Document("testconfig", root)
        request.session["leftfile"] = docu
        request.session["lbadge_int"] = 0
        print(myfile1)
        fs.delete(myfile1)

    elif request.method == 'POST' and "rightfile" in request.FILES.keys():
        
        myfile = request.FILES['rightfile']
        request.session["rfile_name"] = myfile.name
        fs = FileSystemStorage()
        myfile2 = fs.save(myfile.name, myfile)
        
        if request.session["toggleFileType"] == "XML":
            tree = et.parse(myfile2)
            root = tree.getroot()
            docu2 = Document("testconfig", root)
            request.session["rightfile"] = docu2
            request.session["rbadge_int"] = 0
            print(myfile2)
            fs.delete(myfile2)
        
        else:
            handle = open(myfile2)
            plain = PLAIN(handle.read())
            request.session["rightfile"] = plain
            fs.delete(myfile2)
            print(plain.text)


    return HttpResponseRedirect(reverse('viewer:index'))


def close(request):
    
    if request.method == 'POST' and "closeleft" in request.POST.keys():
        if request.session["lbadge_int"] == 0:
       
            try:
                del request.session["leftfile"]
            except: 
                pass
        else:
            request.session["overlay"] = True
            request.session["message"] = "Please save your progress before closing!"
            return HttpResponseRedirect(reverse('viewer:index'))
    elif request.method == 'POST' and "closeright" in request.POST.keys():
        
        
        if request.session.get("toggleFileType",0) == "XML":
        
            if request.session["rbadge_int"] == 0:
                try:
                    del request.session["rightfile"]
                except:
                    pass
            else:
                request.session["overlay"] = True
                request.session["message"] = "Please save your progress before closing!"
                return HttpResponseRedirect(reverse('viewer:index'))
        elif request.session.get("toggleFileType",0) == "TXT":
            try:
                del request.session["rightfile"]
            except:
                pass

        else:
            pass

    return HttpResponseRedirect(reverse('viewer:index'))




def addQUD(request):
    if request.method == 'POST':
        this_seg = request.POST["addQUD"]
        print("present QUD: ", this_seg)
        request.session["scrollPos"] = this_seg

        try:
            doculeft = request.session["leftfile"]
            obj, prev = doculeft.findByID(doculeft.rootqud[0], this_seg, previous=None)
            print(obj)
        except:
            obj = False
        try:
            docuright = request.session["rightfile"]
            obj2, prev2 = docuright.findByID(docuright.rootqud[0], this_seg, previous=None)
        except:
            obj2 = False

        if obj:
            print("added sub qud left")
            newQUD = QUD("enter QUD here ...", "")
            obj.subQUDs = [newQUD] + obj.subQUDs
            doculeft.identifyQUD()
            request.session["lbadge_int"] = request.session.get("lbadge_int",0) + 1
        elif obj2:
            print("added sub qud right")
            newQUD = QUD("?test", "")
            obj2.subQUDs = [newQUD] + obj.subQUDs
            docuright.identifyQUD()
            request.session["rbadge_int"] = request.session.get("rbadge_int",0) + 1

    return HttpResponseRedirect(reverse('viewer:index'))
    #return index(request, scroll=this_seg)



def submitArea(request):

    if request.method == 'POST':
        this_seg = request.POST["submitArea"]
        textinput = request.POST["inputtext"]
        print("present Element: ", this_seg)
        request.session["scrollPos"] = this_seg

        try:
            doculeft = request.session["leftfile"]
            obj, prev = doculeft.findByID(doculeft.rootqud[0], this_seg, previous=None)
            print(obj)
        except:
            obj = False
        try:
            docuright = request.session["rightfile"]
            obj2, prev2 = docuright.findByID(docuright.rootqud[0], this_seg, previous=None)
        except:
            obj2 = False

        if obj:
            if obj.type == "QUD":
                obj.qudForm = textinput
            elif obj.type == "SEGMENT":
                obj.text = textinput
            request.session["lbadge_int"] = request.session.get("lbadge_int",0) + 1
        elif obj2:
            if obj2.type == "QUD":
                obj2.qudForm = textinput
            elif obj2.type == "SEGMENT":
                obj2.text = textinput
            request.session["rbadge_int"] = request.session.get("rbadge_int",0) + 1

            
    return HttpResponseRedirect(reverse('viewer:index'))


def removeQUD(request):

    if request.method == 'POST':
        this_seg = request.POST["removeQUD"]
        print("present QUD: ", this_seg)
        
        try:
            doculeft = request.session["leftfile"]
            obj, prev = doculeft.findByID(doculeft.rootqud[0], this_seg, previous=None)
            print(obj)
        except:
            obj = False
        try:
            docuright = request.session["rightfile"]
            obj2, prev2 = docuright.findByID(docuright.rootqud[0], this_seg, previous=None)
        except:
            obj2 = False

        if obj:
            if obj.identifier == "Q.0":
                request.session["overlay"] = True
                request.session["message"] = "You cannot delete Q.0!"
                return HttpResponseRedirect(reverse('viewer:index'))
            else:

                index = None
                for s in range(len(prev.subQUDs)):
                    if prev.subQUDs[s].idn == obj.idn:
                        index = s
                        break
                    else:
                        continue
                prev.subQUDs = prev.subQUDs[:index] + prev.subQUDs[index+1:]
                request.session["scrollPos"] = prev.idn
                doculeft.identifyQUD()
            request.session["lbadge_int"] = request.session.get("lbadge_int",0) + 1

        elif obj2:
            if obj2.identifier == "Q.0":
                request.session["overlay"] = True
                request.session["message"] = "You cannot delete Q.0!"
                return HttpResponseRedirect(reverse('viewer:index'))
            else:

                index = None
                for s in range(len(prev2.subQUDs)):
                    if prev2.subQUDs[s].idn == obj2.idn:
                        index = s
                        break
                    else:
                        continue
                prev2.subQUDs = prev2.subQUDs[:index] + prev2.subQUDs[index+1:]
                request.session["scrollPos"] = prev2.idn
                docuright.identifyQUD()
            request.session["rbadge_int"] = request.session.get("rbadge_int",0) + 1
        
    return HttpResponseRedirect(reverse('viewer:index'))


def associateQUD(request):


    def isSubbranch(q1, q2):
        # q1 to copy, q2 target
        lq1 = q1.split(".")
        lq2 = q2.split(".")
        # If lengths are identical (equal depth) and one
        # branch is different, ok
        if len(lq1) == len(lq2):
            if any(map(lambda x,y: x!=y,  lq1,lq2)):
                return False
                # else identical and no copy possible
            else:
                return True
        # if depth of copy is lower than target, q1
        # might be a dominating node of q2        
        elif len(lq1) < len(lq2):
            diff = len(lq2) - len(lq1)
            # if one of the first n branches are different,
            # copying is fine since q1 does not dominate q1
            if any(map(lambda x,y: x!=y,  lq1,lq2[:-diff])):
                return False
                # otherwise q1 dominates q2 and copying is not possible
            else:
                return True
        # in case the copy element is deeper than the target node,
        # q1 cannot dominate q2 and copying is ok
        else:
            return False




    if request.method == 'POST' and "associate" in request.POST.keys():
        associate_target = request.POST["associate"]
        this_seg = request.POST["associateButton"]
        print(associate_target, this_seg)
        
        try:
            doculeft = request.session["leftfile"]
            obj, prev = doculeft.findByID(doculeft.rootqud[0], this_seg, previous=None)
            target = doculeft.findQUD(doculeft.rootqud[0], associate_target)
            print(obj)
        except:
            obj = False
        try:
            docuright = request.session["rightfile"]
            obj2, prev2 = docuright.findByID(docuright.rootqud[0], this_seg, previous=None)
            target = docuright.findQUD(docuright.rootqud[0], associate_target)
        except:
            obj2 = False

        if obj and target:
            if obj.identifier == "Q.0":
                request.session["overlay"] = True
                request.session["message"] = "You cannot associate Q.0!"
                return HttpResponseRedirect(reverse('viewer:index'))
            elif isSubbranch(obj.identifier, target.identifier):
                request.session["overlay"] = True
                request.session["message"] = "You cannot rebranch a QUD to a dominated QUD or to itself!"
                return HttpResponseRedirect(reverse('viewer:index'))


            else:

                index = None
                for s in range(len(prev.subQUDs)):
                    if prev.subQUDs[s].idn == obj.idn:
                        index = s
                        break
                    else:
                        continue
                prev.subQUDs = prev.subQUDs[:index] + prev.subQUDs[index+1:]
                target.subQUDs = [obj] + target.subQUDs
                request.session["scrollPos"] = target.idn
                doculeft.identifyQUD()
                request.session["lbadge_int"] = request.session.get("lbadge_int",0) + 1

        elif obj2 and target:
            if obj2.identifier == "Q.0":
                request.session["overlay"] = True
                request.session["message"] = "You cannot associate Q.0!"
                return HttpResponseRedirect(reverse('viewer:index'))

            elif isSubbranch(obj2.identifier, target.identifier):
                request.session["overlay"] = True
                request.session["message"] = "You cannot rebranch a QUD to a dominated QUD or to itself!"
                return HttpResponseRedirect(reverse('viewer:index'))


            else:

                index = None
                for s in range(len(prev2.subQUDs)):
                    if prev2.subQUDs[s].idn == obj2.idn:
                        index = s
                        break
                    else:
                        continue
                prev2.subQUDs = prev2.subQUDs[:index] + prev2.subQUDs[index+1:]
                target.subQUDs = [obj] + target.subQUDs
                request.session["scrollPos"] = target.idn
                docuright.identifyQUD()
                request.session["rbadge_int"] = request.session.get("rbadge_int",0) + 1

        else:
            
            request.session["overlay"] = True
            request.session["message"] = "Target QUD does not exist!"
            return HttpResponseRedirect(reverse('viewer:index'))

    return HttpResponseRedirect(reverse('viewer:index'))


def addSubSegment(request):
    if request.method == 'POST':
        this_seg = request.POST["addSegment"]
        print("present Segment: ", this_seg)
        request.session["scrollPos"] = this_seg

        try:
            doculeft = request.session["leftfile"]
            obj, prev = doculeft.findByID(doculeft.rootqud[0], this_seg, previous=None)
            print(obj)
        except:
            obj = False
        try:
            docuright = request.session["rightfile"]
            obj2, prev2 = docuright.findByID(docuright.rootqud[0], this_seg, previous=None)
        except:
            obj2 = False

        if obj:
            if obj.type == "QUD":
                newSeg = SEGMENT("Enter Segment here...")
                obj.segList = [newSeg] + obj.segList
                
            else:
                newSeg = SEGMENT("Enter Segment here...")
                obj.subsegments = [newSeg] + obj.subsegments
            request.session["lbadge_int"] = request.session.get("lbadge_int",0) + 1
                
            
        elif obj2:

            if obj2.type == "QUD":
                newSeg = SEGMENT("Enter Segment here...")
                obj2.segList = [newSeg] + obj2.segList
                
            else:
                newSeg = SEGMENT("Enter Segment here...")
                obj2.subsegments = [newSeg] + obj2.subsegments
            request.session["rbadge_int"] = request.session.get("rbadge_int",0) + 1



    return HttpResponseRedirect(reverse('viewer:index'))

def moveDown(request):

    def shiftd(obj, prev):
        if obj.type == "SEGMENT":
            if prev.type == "SEGMENT":
                index = None
                for s in range(len(prev.subsegments)):
                    if prev.subsegments[s].idn == obj.idn:
                        index = s
                        break
                    else:
                        continue
                if index == len(prev.subsegments)-1:
                    return 0
                elif index < len(prev.subsegments)-1:
                    prev.subsegments = prev.subsegments[:index] + [prev.subsegments[index+1]] + [prev.subsegments[index]] + prev.subsegments[index+2:] 
            elif prev.type == "QUD":
                index = None
                for s in range(len(prev.segList)):
                    if prev.segList[s].idn == obj.idn:
                        index = s
                        break
                    else:
                        continue
                if index == len(prev.segList)-1:
                    return 0
                elif index < len(prev.segList)-1:
                    prev.segList = prev.segList[:index] + [prev.segList[index+1]] + [prev.segList[index]] + prev.segList[index+2:]
            
        elif obj.type == "QUD":
            index = None
            for s in range(len(prev.subQUDs)):
                if prev.subQUDs[s].idn == obj.idn:
                    index = s
                    break
                else:
                    continue
            if index == len(prev.subQUDs)-1:
                return 0
            elif index < len(prev.subQUDs)-1:
                prev.subQUDs = prev.subQUDs[:index] + [prev.subQUDs[index+1]] + [prev.subQUDs[index]] + prev.subQUDs[index+2:] 
                
    if request.method == 'POST':
        this_seg = request.POST["pushDown"]
        request.session["scrollPos"] = this_seg
        print("present QUD: ", this_seg)
        
        try:
            doculeft = request.session["leftfile"]
            obj, prev = doculeft.findByID(doculeft.rootqud[0], this_seg, previous=None)
            print(obj)
        except:
            obj = False
        try:
            docuright = request.session["rightfile"]
            obj2, prev2 = docuright.findByID(docuright.rootqud[0], this_seg, previous=None)
        except:
            obj2 = False

        if obj:
            shiftd(obj, prev)
            doculeft.identifyQUD()
            request.session["lbadge_int"] = request.session.get("lbadge_int",0) + 1

        elif obj2:
            shiftd(obj2, prev2)
            docuright.identifyQUD()
            request.session["rbadge_int"] = request.session.get("rbadge_int",0) + 1
            
            
    return HttpResponseRedirect(reverse('viewer:index'))



def moveUp(request):
    def shiftu(obj, prev):
        if obj.type == "SEGMENT":
            if prev.type == "SEGMENT":
                index = None
                for s in range(len(prev.subsegments)):
                    if prev.subsegments[s].idn == obj.idn:
                        index = s
                        break
                    else:
                        continue
                if index == 0:
                    return 0
                elif index > 0:
                    prev.subsegments = prev.subsegments[:index-1] + [prev.subsegments[index]] + [prev.subsegments[index-1]] + prev.subsegments[index+1:] 
            elif prev.type == "QUD":
                index = None
                for s in range(len(prev.segList)):
                    if prev.segList[s].idn == obj.idn:
                        index = s
                        break
                    else:
                        continue
                if index == 0:
                    return 0
                elif index > 0:
                    prev.segList = prev.segList[:index-1] + [prev.segList[index]] + [prev.segList[index-1]] + prev.segList[index+1:] 
            
            
        elif obj.type == "QUD":
            index = None
            for s in range(len(prev.subQUDs)):
                if prev.subQUDs[s].idn == obj.idn:
                    index = s
                    break
                else:
                    continue
            if index == 0:
                return 0
            elif index > 0:
                prev.subQUDs = prev.subQUDs[:index-1] + [prev.subQUDs[index]] + [prev.subQUDs[index-1]] + prev.subQUDs[index+1:] 
            

    if request.method == 'POST':
        this_seg = request.POST["pushUp"]
        request.session["scrollPos"] = this_seg
        print("present QUD: ", this_seg)
        
        try:
            doculeft = request.session["leftfile"]
            obj, prev = doculeft.findByID(doculeft.rootqud[0], this_seg, previous=None)
            print(obj)
        except:
            obj = False
        try:
            docuright = request.session["rightfile"]
            obj2, prev2 = docuright.findByID(docuright.rootqud[0], this_seg, previous=None)
        except:
            obj2 = False

        if obj:
            shiftu(obj, prev)
            doculeft.identifyQUD()
            request.session["lbadge_int"] = request.session.get("lbadge_int",0) + 1

        elif obj2:
            shiftu(obj2, prev2)
            docuright.identifyQUD()
            request.session["rbadge_int"] = request.session.get("rbadge_int",0) + 1
            
            
    return HttpResponseRedirect(reverse('viewer:index'))


def associateSegment(request):

    def associate(obj, prev, target):
        if prev.type == "QUD":
            index = None
            for s in range(len(prev.segList)):
                if prev.segList[s].idn == obj.idn:
                    index = s
                    break
                else:
                    continue
            prev.segList = prev.segList[:index] + prev.segList[index+1:]
            target.segList = [obj] + target.segList
            request.session["scrollPos"] = target.idn

        else:
            index = None
            for s in range(len(prev.subsegments)):
                if prev.subsegments[s].idn == obj.idn:
                    index = s
                    break
                else:
                    continue
            prev.subsegments = prev.subsegments[:index] + prev.subsegments[index+1:]
            target.segList = [obj] + target.segList
            request.session["scrollPos"] = target.idn
            



    if request.method == 'POST' and "associate" in request.POST.keys():
        associate_target = request.POST["associate"]
        this_seg = request.POST["associatebutton"]
        print(associate_target, this_seg)
        
        try:
            doculeft = request.session["leftfile"]
            obj, prev = doculeft.findByID(doculeft.rootqud[0], this_seg, previous=None)
            target = doculeft.findQUD(doculeft.rootqud[0], associate_target)
            print(obj)
        except:
            obj = False
        try:
            docuright = request.session["rightfile"]
            obj2, prev2 = docuright.findByID(docuright.rootqud[0], this_seg, previous=None)
            target = docuright.findQUD(docuright.rootqud[0], associate_target)
        except:
            obj2 = False

        if obj:
           associate(obj, prev, target)
           request.session["lbadge_int"] = request.session.get("lbadge_int",0) + 1

        elif obj2:
           associate(obj2, prev2, target)
           request.session["rbadge_int"] = request.session.get("rbadge_int",0) + 1

    return HttpResponseRedirect(reverse('viewer:index'))




def removeSegment(request):

    if request.method == 'POST' and "removeSegment" in request.POST.keys():
        this_seg = request.POST["removeSegment"]
        print("present Segment: ", this_seg)
        
        try:
            doculeft = request.session["leftfile"]
            obj, prev = doculeft.findByID(doculeft.rootqud[0], this_seg, previous=None)
            print(obj)
        except:
            obj = False
        try:
            docuright = request.session["rightfile"]
            obj2, prev2 = docuright.findByID(docuright.rootqud[0], this_seg, previous=None)
        except:
            obj2 = False

        if obj:
            if prev.type == "QUD":
                index = None
                for s in range(len(prev.segList)):
                    if prev.segList[s].idn == obj.idn:
                        index = s
                        break
                    else:
                        continue
                prev.segList = prev.segList[:index] + prev.segList[index+1:]
                request.session["scrollPos"] = prev.idn
            else:
                index = None
                for s in range(len(prev.subsegments)):
                    if prev.subsegments[s].idn == obj.idn:
                        index = s
                        break
                    else:
                        continue
                prev.subsegments = prev.subsegments[:index] + prev.subsegments[index+1:]
                request.session["scrollPos"] = prev.idn
            request.session["lbadge_int"] = request.session.get("lbadge_int",0) + 1



        elif obj2:
            if prev2.type == "QUD":
                index = None
                for s in range(len(prev2.segList)):
                    if prev2.segList[s].idn == obj2.idn:
                        index = s
                        break
                    else:
                        continue
                prev2.segList = prev2.segList[:index] + prev2.segList[index+1:]
                request.session["scrollPos"] = prev2.idn
            else:
                index = None
                for s in range(len(prev2.subsegments)):
                    if prev2.subsegments[s].idn == obj2.idn:
                        index = s
                        break
                    else:
                        continue
                prev2.subsegments = prev2.subsegments[:index] + prev2.subsegments[index+1:]
                request.session["scrollPos"] = prev2.idn
            request.session["rbadge_int"] = request.session.get("rbadge_int",0) + 1
        
    return HttpResponseRedirect(reverse('viewer:index'))






def classify(request):
    if request.method == 'POST' and "classify" in request.POST.keys():
        this_seg = request.POST["classifybutton"]
        this_class = request.POST["classify"]
        print("present Element: ", this_seg)
        request.session["scrollPos"] = this_seg

        try:
            doculeft = request.session["leftfile"]
            obj, prev = doculeft.findByID(doculeft.rootqud[0], this_seg, previous=None)
            print(obj)
        except:
            obj = False
        try:
            docuright = request.session["rightfile"]
            obj2, prev2 = docuright.findByID(docuright.rootqud[0], this_seg, previous=None)
        except:
            obj2 = False

        if obj:
            obj.classification = this_class
            request.session["lbadge_int"] = request.session.get("lbadge_int",0) + 1
        elif obj2:
            obj2.classification = this_class
            request.session["rbadge_int"] = request.session.get("rbadge_int",0) + 1

            
    return HttpResponseRedirect(reverse('viewer:index'))


def saveSegID(request):
    if request.method == 'POST':
        this_seg = request.POST["saveSegID"]
        this_idinput = request.POST["saveSegIDInput"]
        print("present Segment: ", this_seg)
        request.session["scrollPos"] = this_seg

        try:
            doculeft = request.session["leftfile"]
            obj, prev = doculeft.findByID(doculeft.rootqud[0], this_seg, previous=None)
            print(obj)
        except:
            obj = False
        try:
            docuright = request.session["rightfile"]
            obj2, prev2 = docuright.findByID(docuright.rootqud[0], this_seg, previous=None)
        except:
            obj2 = False


        if obj:
            obj.identifier = this_idinput
            request.session["lbadge_int"] = request.session.get("lbadge_int",0) + 1

        elif obj2:
            obj2.identifier = this_idinput
            request.session["rbadge_int"] = request.session.get("rbadge_int",0) + 1

    return HttpResponseRedirect(reverse('viewer:index'))



def saveFile(request):
    if request.method == 'POST':
        if "saveleft" in request.POST.keys():
            doculeft =  request.session["leftfile"]

            nonclassSegms = []
            doculeft.getAllUnclassifiedSegments(doculeft.rootqud[0], nonclassSegms)
            
            if nonclassSegms:
                first = nonclassSegms[0]
                request.session["overlay"] = True
                request.session["message"] = "Please classify the SEGMENT in Focus first!"
                request.session["scrollPos"] = first
                return HttpResponseRedirect(reverse('viewer:index'))









            file_obj = doculeft.toXML()
            request.session["lbadge_int"] = 0
            response = HttpResponse(file_obj, content_type='text/xml')
            if "lfile_name" in request.session.keys():
                response['Content-Disposition'] = 'attachment; filename={}'.format(request.session["lfile_name"])
            else:
                response['Content-Disposition'] = 'attachment; filename=download.xml'
            
            return response
            
        elif "saveright" in request.POST.keys():
            docuright =  request.session["rightfile"]
            file_obj = docuright.toXML()
            request.session["rbadge_int"] = 0
            response = HttpResponse(file_obj, content_type='text/xml')
            response['Content-Disposition'] = 'attachment; filename=download.xml'
            
            return response

    

def toggleFileType(request):
    if request.method == "POST" and "toggleFileType" in request.POST.keys():
        if request.session["toggleFileType"] == "XML":
            request.session["toggleFileType"] = "TXT"
            print("filetype changed to TXT")
        elif request.session["toggleFileType"] == "TXT":
            request.session["toggleFileType"] = "XML"
            print("filetype changed to XML")
        else:
            print("toggle filetype failed")
    
    return HttpResponseRedirect(reverse('viewer:index'))
    


def initiate(request):
    if request.method == 'POST':

        if request.session.get("lbadge_int",0) == 0 and request.session.get("rbadge_int",0) == 0:
            if "initleft" in request.POST.keys():
                
                doculeft = Document("","")
                newQUD = QUD("", "")
                doculeft.rootqud = [newQUD]
                doculeft.identifyQUD()
                request.session["leftfile"] = doculeft
                request.session["lbadge_int"] = 1
            elif "initright" in request.POST.keys():
                            
                docuright = Document("","")
                newQUD = QUD("", "")
                docuright.rootqud = [newQUD]
                docuright.identifyQUD()
                request.session["rightfile"] = docuright
                request.session["rbadge_int"] = 1
        else:
            request.session["overlay"] = True
            request.session["message"] = "Please save your progress before starting a new annotation!"
            return HttpResponseRedirect(reverse('viewer:index'))


    return HttpResponseRedirect(reverse('viewer:index'))