from django.urls import path

from . import views

app_name = 'viewer'
urlpatterns = [
    path('', views.index, name='index'),
    path('openFile/', views.openFile, name='openFile'),
    path('close/', views.close, name='close'),
    path('addQUD/', views.addQUD, name='addQUD'),
    path('removeQUD/', views.removeQUD, name='removeQUD'),
    path('associateQUD/', views.associateQUD, name='associateQUD'),
    path('addSubSegment/', views.addSubSegment, name='addSubSegment'),
    path('moveDown/', views.moveDown, name='moveDown'),
    path('moveUp/', views.moveUp, name='moveUp'),
    path('submitArea/', views.submitArea, name='submitArea'),
    path('removeSegment/', views.removeSegment, name='removeSegment'),
    path('associateSegment/', views.associateSegment, name='associateSegment'),
    path('classify/', views.classify, name='classify'),
    path('saveFile/', views.saveFile, name="saveFile"),
    path('initiate/', views.initiate, name="initiate"),
    path('loggingin/', views.loggingin, name="loggingin"),
    path('checklogin/', views.checklogin, name="checklogin"),
    path('loggingout/', views.loggingout, name="loggingout"),
    path('toggleFileType/', views.toggleFileType, name="toggleFileType"),
    path('saveSegID/', views.saveSegID, name="saveSegID") 
]
