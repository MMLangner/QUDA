@ECHO off

python -V | find /v "Python" >NUL 2>NUL && (goto :PYTHON_DOES_NOT_EXIST)
python -V | find "Python" >NUL 2>NUL && (goto :PYTHON_DOES_EXIST)
PAUSE

:PYTHON_DOES_NOT_EXIST
ECHO Python is not installed on your system.
ECHO Now opening the download URL.
START "" "https://www.python.org/downloads/windows/"
PAUSE

:PYTHON_DOES_EXIST
ECHO Your computer runs Python, continueing to setup QUDA...
ECHO installing dependencies of QUDA...
pip install django
pip install django_downloadview
pip install numpy
ECHO requirements installed. Please use QUDA_start file to start app.
PAUSE